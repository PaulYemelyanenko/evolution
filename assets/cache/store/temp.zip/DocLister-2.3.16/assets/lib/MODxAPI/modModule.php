<?php
include_once(dirname(__FILE__) . "/autoTable.abstract.php");

/**
 * Class modModule
 */
class modModule extends autoTable
{
    /**
     * @var string
     */
    protected $table = "site_modules";
}
