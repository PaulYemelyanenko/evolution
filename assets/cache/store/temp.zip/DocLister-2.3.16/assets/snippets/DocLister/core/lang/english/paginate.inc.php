<?php
if ( ! defined('MODX_BASE_PATH')) {
    die('What are you doing? Get out of here!');
}

$_lang = array();
$_lang['next'] = 'Next';
$_lang['prev'] = 'Prev';

return $_lang;
