<?php
if ( ! defined('MODX_BASE_PATH')) {
    die('What are you doing? Get out of here!');
}

setlocale(LC_ALL, 'pl_PL.UTF-8');

$_lang = array();
$_lang['hello'] = 'Cześć';

return $_lang;
