<?php
if ( ! defined('MODX_BASE_PATH')) {
    die('What are you doing? Get out of here!');
}

setlocale(LC_ALL, 'ru_RU.UTF-8');

$_lang = array();
$_lang['next'] = 'Далее';
$_lang['prev'] = 'Назад';

return $_lang;
